#ifndef PHASIDX_H
#define PHASIDX_H
void phasidx(long *i,long phasno,long spt,long ept);
#endif /* PHASIDX_H */
