#ifndef OUTLMOD_H
#define OUTLMOD_H
void outlmod(void);
#endif /* OUTLMOD_H */
