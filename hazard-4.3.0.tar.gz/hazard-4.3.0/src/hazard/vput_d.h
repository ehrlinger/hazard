#ifndef VPUT_D_H
#define VPUT_D_H
void vput_d(char *spcnam,char *varnam,long misval,long delval,
	    double minval, double maxval,size_t spclen);
#endif /* VPUT_D_H */
