#ifndef CRPT_D_H
#define CRPT_D_H

void crpt_d(void);
#endif /* CRPT_D_H */
