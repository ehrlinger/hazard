#ifndef SETOBS_H
#define SETOBS_H

void setobs(void);
#endif /* SETOBS */

