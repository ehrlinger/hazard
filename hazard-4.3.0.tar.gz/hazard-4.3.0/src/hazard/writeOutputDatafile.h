#ifndef WRITE_OUTPUT_DATAFILE_H
#define WRITE_OUTPUT_DATAFILE_H
/*
  Definition location for writeOutputDatafile.c file.
*/
void writeOutputDatafile(void);

#endif /* WRITE_OUTPUT_DATAFILE_H */
