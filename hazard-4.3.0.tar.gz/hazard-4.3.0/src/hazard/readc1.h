#ifndef READC1_H
#define READC1_H

void readc1(void);
#endif /* READC1 */

