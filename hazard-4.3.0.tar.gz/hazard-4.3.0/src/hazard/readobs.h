#ifndef READOBS_H
#define READOBS_H

void readobs(void);
#endif /* READOBS */

