#ifndef CONCRPT_H
#define CONCRPT_H
void concrpt(void);
#endif /* CONCRPT_H */
