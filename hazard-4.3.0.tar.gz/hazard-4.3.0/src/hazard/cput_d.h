#ifndef CPUT_D_H
#define CPUT_D_H

void cput_d(char *phasnm,long j);
#endif /* CPUT_D_H */

