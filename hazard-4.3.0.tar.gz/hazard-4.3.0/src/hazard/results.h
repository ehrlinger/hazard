#ifndef RESULTS_H
#define RESULTS_H

void results(void);
#endif /* RESULTS_H */

