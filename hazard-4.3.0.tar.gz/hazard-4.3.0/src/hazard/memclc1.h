#ifndef MEMCLC1_H
#define MEMCLC1_H
void memclc1(long phasno,long xt1st,long *xt2nd,long *xt3rd,
	     long *xt4th,long *xt5th);
#endif /* MEMCLC1_H */
