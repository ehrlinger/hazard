#ifndef CPUT_VV_H
#define CPUT_VV_H

void cput_vv(char *phasnm,long *iary,void (*cputfn)(char *,long));
#endif /* CPUT_VV_H */
