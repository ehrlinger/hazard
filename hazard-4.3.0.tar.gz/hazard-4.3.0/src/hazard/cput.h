#ifndef CPUT_H
#define CPUT_H

void cput(char *phasnm,long j);
#endif /* CPUT_H */
