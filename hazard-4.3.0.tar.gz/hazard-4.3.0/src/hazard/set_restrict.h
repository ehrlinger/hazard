#ifndef SETREST_H
#define SETREST_H

void set_restrict(void);
#endif /* SETREST_H */
