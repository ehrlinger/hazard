#ifndef MODTERM_H
#define MODTERM_H

void modterm(logical iflag);
#endif /* MODTERM_H */
