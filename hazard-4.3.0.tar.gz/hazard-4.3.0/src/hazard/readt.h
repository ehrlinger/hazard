#ifndef READT_H
#define READT_H

void readt(void);
#endif /* READT */

