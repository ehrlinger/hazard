#ifndef THETA_X_H
#define THETA_X_H

void theta_x(void);

#endif /* THETA_X_H */
