#ifndef SETSTAT_H
#define SETSTAT_H
void setstat(long i,long idx,long *phasevar,long *itabl,long *ipxc);
#endif /* SETSTAT_H */
