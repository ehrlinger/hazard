#ifndef CPUT_DL_H
#define CPUT_DL_H
void cput_dl(char *phasnm,long j);
#endif /* CPUT_DL_H */
