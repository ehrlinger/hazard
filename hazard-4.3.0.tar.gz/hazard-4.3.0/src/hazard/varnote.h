#ifndef VARNOTE_H
#define VARNOTE_H

void varnote(void);
#endif /* VARNOTE_H */
