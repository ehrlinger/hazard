#ifndef HZRBOMB_H
#define HZRBOMB_H

void hzrbomb(void);
#endif /* HZRBOMB_H */

