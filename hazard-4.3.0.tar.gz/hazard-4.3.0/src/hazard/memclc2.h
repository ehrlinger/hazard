#ifndef MEMCLC2_H
#define MEMCLC2_H
void memclc2(long phasno,long xt1st,long *xt2nd);
#endif /* MEMCLC2_H */
