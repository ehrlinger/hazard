#ifndef CPUT_L_H
#define CPUT_L_H

void cput_l(char *phasnm,long j);
#endif /* CPUT_L_H */
