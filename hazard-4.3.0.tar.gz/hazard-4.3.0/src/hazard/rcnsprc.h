#ifndef RCNSPRC_H
#define RCNSPRC_H
extern void rcnsprc(void);

#endif /* RCNSPRC_H */
