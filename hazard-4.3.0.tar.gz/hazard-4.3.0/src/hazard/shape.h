#ifndef SHAPE_H
#define SHAPE_H

void shape(void);
#endif /* SHAPE_H */
