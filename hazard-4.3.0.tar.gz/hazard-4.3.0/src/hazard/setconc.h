#ifndef SETCONC_H
#define SETCONC_H
void setconc(void);

#endif /* SETCONC_H */
