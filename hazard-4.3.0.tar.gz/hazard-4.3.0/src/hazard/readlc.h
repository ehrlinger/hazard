#ifndef READLC_H
#define READLC_H

void readlc(void);
#endif /* READLC */

