#ifndef VPUT_DL_H
#define VPUT_DL_H

void vput_dl(char *spcnam,char *varnam,char *label,long misval,long delval,
	     double minval,double maxval,size_t spclen);
#endif /* VPUT_DL_H */
