#ifndef READC3_H
#define READC3_H

void readc3(void);
#endif /* READC3 */

