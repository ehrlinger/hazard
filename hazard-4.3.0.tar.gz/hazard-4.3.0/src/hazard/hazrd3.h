#ifndef _HAZRD3_H_
#define _HAZRD3_H_
/*
  Definition location for hazrd3.c file.
*/
void HAZRD3(void);
void STPNOTE(void);
void OPTNOTE(void);
void OPTHDR(void);
void OPTPRTX(void);
void RETRY_T(void);
void HAZ3TRM(long);

#endif /* _HAZRD3_H_ */
