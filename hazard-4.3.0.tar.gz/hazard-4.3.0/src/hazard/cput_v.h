#ifndef CPUT_V_H
#define CPUT_V_H

void cput_v(long dashct,long dashat,void (*cputfn)(char *,long));
#endif /* CPUT_V_H */

