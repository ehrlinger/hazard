#ifndef SETPRMF_H
#define SETPRMF_H

void setprmf(long,long,long,long,double *);

#endif /* SETPRMF_H */
