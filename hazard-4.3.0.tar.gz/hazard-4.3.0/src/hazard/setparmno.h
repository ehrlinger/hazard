#ifndef SETPARM_H
#define SETPARM_H

void setparmno(long parmno,long ispecno,long phaseno,double *fixpvar);

#endif /* SETPARM_H */
