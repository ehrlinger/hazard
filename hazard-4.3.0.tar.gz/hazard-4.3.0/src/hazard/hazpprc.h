#ifndef HAZPPRC_H
#define HAZPPRC_H

extern void hazpprc(void);

#endif /* HAZPPRC_H */
