#ifndef LCNSPRC_H
#define LCNSPRC_H

extern void lcnsprc(void);

#endif /* LCNSPRC_H */
