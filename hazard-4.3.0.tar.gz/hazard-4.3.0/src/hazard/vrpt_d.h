#ifndef VRPT_D_H
#define VRPT_D_H
void vrpt_d(void);
#endif /* VRPT_D_H */
