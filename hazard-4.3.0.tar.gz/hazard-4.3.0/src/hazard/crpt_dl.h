#ifndef CRPT_DL_H
#define CRPT_DL_H

void crpt_dl(void);
#endif /* CRPT_DL_H */
