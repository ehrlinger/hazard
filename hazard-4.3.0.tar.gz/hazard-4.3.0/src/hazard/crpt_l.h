#ifndef CRPT_L_H
#define CRPT_L_H

void crpt_l(void);
#endif /* CRPT_L_H */
