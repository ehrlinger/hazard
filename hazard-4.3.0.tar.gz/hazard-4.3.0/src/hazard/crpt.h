#ifndef CRPT_H
#define CRPT_H
void crpt(void);
#endif /* CRPT_H */
