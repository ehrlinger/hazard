#ifndef ISMUCHG_H
#define ISMUCHG_H

void ismuchg(float spec,float used,char *flag);
#endif /* ISMUCHG_H */
