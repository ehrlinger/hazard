#ifndef FINPRMX_H
#define FINPRMX_H

void finprmx(long *i,long phasno,long spt,long ept);
#endif /* FINPRMX_H */
