#ifndef _HAZRD2_H_
#define _HAZRD2_H_
/*
  Definition location for hazard.c file.
*/
void HAZRD2(void);
void HZ2LOOP(void);
void DOOPTIM(void);
void SETOPTX(long,long);
void NOOPTIM(void);
void HAZ2TRM(long);


#endif /* _HAZRD2_H_ */
