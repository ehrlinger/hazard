#ifndef SETIDXS_H
#define SETIDXS_H
void setidxs(long i,long j);
#endif /* SETIDXS_H */

