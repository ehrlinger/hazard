#ifndef VFYNVAR_H
#define VFYNVAR_H

extern long vfynvar(struct namestr *,char *);

#endif /* VFYNVAR_H */
