#ifndef VARSRPT_H
#define VARSRPT_H

void varsrpt(void);
#endif /* VARSRPT_H */
