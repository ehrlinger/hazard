#include "shape.h"

void hzrg(void){
  shape();
}
