#ifndef READC2_H
#define READC2_H

void readc2(void);
#endif /* READC2 */

