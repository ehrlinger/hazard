#ifndef HZRI_H
#define HZRI_H
struct common *hzri(void);
#endif /* HZRI_H */
