#ifndef STPWPRC_H
#define STPWPRC_H

extern void stpwprc(void);

#endif /* STPWPRC_H */
