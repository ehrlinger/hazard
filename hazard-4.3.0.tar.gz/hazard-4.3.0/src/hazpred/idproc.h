#ifndef IDPROC_H
#define IDPROC_H

void idproc(void);
#endif /* IDPROC_H */
