#include "hazpred.h"
#include "stmtfld.h"

void cntobsi(void){
  totalobs = stmtfld(12);
}
