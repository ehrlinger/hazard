#ifndef HAZVERR_H
#define HAZVERR_H 
void hazverr(long varnum);
#endif /* HAZVERR_H */
