void hazpprc(void);
