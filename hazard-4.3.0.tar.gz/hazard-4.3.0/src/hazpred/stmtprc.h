#ifndef STMTPRC_H
#define STMTPRC_H
void stmtprc(void);
#endif /* STMTPRC_H */
