#ifndef PREDERR_H
#define PREDERR_H

void prederr(void);
#endif /* PREDERR_H */
