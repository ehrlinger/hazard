#ifndef GETFLAG_H
#define GETFLAG_H

int getflag(char *,long);
#endif /* GETFLAG_H */
