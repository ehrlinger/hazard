#ifndef OPENFILS_H
#define OPENFILS_H
void opnfils(void);
#endif /* OPENFILS_H */
