#ifndef FMTVERR_H
#define FMTVERR_H

void fmtverr(long varnum,char *name,char *namv);
#endif /* FMTVERR_H */
