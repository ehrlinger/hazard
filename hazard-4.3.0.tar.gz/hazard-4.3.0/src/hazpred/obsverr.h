#ifndef OBSVERR_H
#define OBSVERR_H

void obsverr(long obsnum);
#endif /* OBSVERR_H */
