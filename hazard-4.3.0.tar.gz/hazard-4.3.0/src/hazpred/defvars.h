#ifndef DEFVARS_H
#define DEFVARS_H

void defvars(void);
#endif /* DEFVARS_H */
