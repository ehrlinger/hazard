#ifndef ALOCMEM_H
#define ALOCMEM_H

void alocmem(void);
#endif /* ALOCMEM_H */
