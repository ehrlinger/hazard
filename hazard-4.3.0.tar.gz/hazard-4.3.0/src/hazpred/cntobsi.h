#ifndef CNTOBSI_H
#define CNTOBSI_H

void cntobsi(void);
#endif /* CNTOBSI_H */
