#ifndef DFAST_H
#define DFAST_H

void DFAST(double *beta,long nvar,double *cov,long ivar,double *sd,
	   double *znorm,double *pnorm);

#endif /* DFAST_H */
