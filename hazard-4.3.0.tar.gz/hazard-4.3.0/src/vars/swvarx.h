#ifndef SWVARX_H
#define SWVARX_H
void SWVARX(short int *status,double *pvalue,long *moves,long *mxmove);
#endif /* SWVARX_H */

