#ifndef STEPW_H
#define STEPW_H

void STEPW(short int *status,double *pvalue,long *moves,long *mxmove,
	   double *zvalue,double *stdErr,long *flags,double *qx,
	   double *qtols,double *d2ll,long nvar,double *wk,double *d2llad,
	   long *rstvec);

 
#endif /* STEPW_H */
