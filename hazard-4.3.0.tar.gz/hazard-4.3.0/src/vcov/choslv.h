#ifndef CHOSLV_H
#define CHOSLV_H
void CHOSLV(double *l,double *g,double *s,long n);

#endif /* CHOSLV_H */
