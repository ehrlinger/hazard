#ifndef SETCOE_CALC_SCALING_H
#define SETCOE_CALC_SCALING_H

void SETCOE_calc_scaling(void);
#endif /* SETCOE_CALC_SCALING_H */
