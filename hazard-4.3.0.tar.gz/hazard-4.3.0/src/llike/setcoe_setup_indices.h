#ifndef SETCOE_SETUP_INDICES_H
#define SETCOE_SETUP_INDICES_H
void SETCOE_setup_indices(void);
#endif /* SETCOE_SETUP_INDICES_H */
