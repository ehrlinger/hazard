#ifndef SETCOE_OBS_LOOP_H
#define SETCOE_OBS_LOOP_H

logical SETCOE_obs_loop(void);
#endif /* SETCOE_OBS_LOOP_H */
