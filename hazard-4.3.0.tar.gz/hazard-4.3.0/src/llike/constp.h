#ifndef CONSTP_H
#define CONSTP_H

void constp(void);
#endif /* CONSTP_H */
