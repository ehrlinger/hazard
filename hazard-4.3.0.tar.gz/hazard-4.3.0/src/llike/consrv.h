#ifndef CONSRV_H
#define CONSRV_H

void consrv(void);
#endif /* CONSRV_H */
