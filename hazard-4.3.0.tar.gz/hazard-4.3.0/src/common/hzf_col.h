#ifndef HZF_COL_H
#define HZF_COL_H

void hzf_col(long column);

#endif /* HZF_COL_H */
