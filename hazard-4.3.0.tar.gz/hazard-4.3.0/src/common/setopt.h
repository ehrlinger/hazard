#ifndef SETOPT_H
#define SETOPT_H

void setopt(int which);
#endif /* SETOPT_H */
