#ifndef HZFPAG_H
#define HZFPAG_H

void hzfpag(long count);

#endif /* HZFPAG_H */
