#ifndef HZD_LATE_T2P_H
#define HZD_LATE_T2P_H

void hzd_late_t2p(void);
#endif /* HZD_LATE_T2P_H */
