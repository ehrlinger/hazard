#ifndef NOTSPEC_H
#define NOTSPEC_H
#include "structures.h" /* Defines logical */

logical notspec(long fldno);
#endif /* NOTSPEC_H */
