#ifndef HZFXPR_H
#define HZFXPR_H

void hzfxpr(char byte,long times,long column);

#endif /* HZFXPR_H */
