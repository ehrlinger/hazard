#ifndef XVPUTI_H
#define  XVPUTI_H

void xvputi(long nvar);

#endif /* XVPUTI_H */



