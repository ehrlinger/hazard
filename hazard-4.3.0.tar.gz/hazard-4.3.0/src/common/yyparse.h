#ifndef YYPARSE_H
#define YYPARSE_H

extern int yysynerr;
void yyparse(void);

#endif /* YYPARSE_H */
