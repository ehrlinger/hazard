#ifndef HZFSKP_H
#define HZFSKP_H

void hzfskp(long count);

#endif /* HZFSKP_H */
