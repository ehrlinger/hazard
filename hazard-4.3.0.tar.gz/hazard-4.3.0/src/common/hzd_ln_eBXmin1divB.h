#ifndef HZD_LN_EBXMIN1DIVB_H
#define HZD_LN_EBXMIN1DIVB_H

double hzd_ln_eBXmin1divB(double BETA,double X);
#endif /* HZD_LN_EBXMIN1DIVB_H */
