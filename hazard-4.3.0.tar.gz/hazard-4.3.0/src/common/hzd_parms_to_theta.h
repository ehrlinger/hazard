#ifndef HZD_PARMS_TO_THETA_H
#define HZD_PARMS_TO_THETA_H
void hzd_parms_to_theta(void);
#endif /* HZD_PARMS_TO_THETA_H */
