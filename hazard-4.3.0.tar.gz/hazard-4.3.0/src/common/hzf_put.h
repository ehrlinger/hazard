#ifndef HZF_PUT_H
#define HZF_PUT_H

void hzf_put(long leng,char *strg);

#endif /* HZF_PUT_H */
