#ifndef XMISSGOT_H
#define XMISSGOT_H

#include "structures.h" /* defines logical */

logical xMISSgot(void *value,int len);

#endif /* XMISSGOT_H */
