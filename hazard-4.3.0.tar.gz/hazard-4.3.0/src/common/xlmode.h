#ifndef XLMODE_H
#define XLMODE_H

void xlmode(long setting);

#endif /* XLMODE_H */
