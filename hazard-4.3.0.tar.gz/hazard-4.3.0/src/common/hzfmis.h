#ifndef HZFMIS_H
#define HZFMIS_H

void hzfmis(void *var);

#define MKMISS(x) hzfmis(&x)

#endif /* HZFMIS_H */
