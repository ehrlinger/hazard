#ifndef HZFLG2_H
#define HZFLG2_H

void hzflg2(char *strg1,long leng1,char *strg2,long leng2);

#endif /* HZFLG2_H */
