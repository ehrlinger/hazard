#ifndef YYERROR_H
#define YYERROR_H

int yyerror(char *s);
#endif /* YYERROR_H */

