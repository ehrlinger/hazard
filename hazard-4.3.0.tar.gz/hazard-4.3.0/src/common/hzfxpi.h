#ifndef HZFXPI_H
#define HZFXPI_H

void hzfxpi(long value,long places,long column);

#endif /* HZFXPI_H */
