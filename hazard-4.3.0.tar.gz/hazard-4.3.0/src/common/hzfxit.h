#ifndef HZFXIT_H
#define HZFXIT_H

void hzfxit(char *type);

#endif /* HZFXIT_H */
