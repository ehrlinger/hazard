#ifndef HZD_LN_1MIN_ENEGX_H
#define HZD_LN_1MIN_ENEGX_H

double hzd_ln_1min_enegX(double X);
#endif /* HZD_LN_1MIN_ENEGX_H*/
