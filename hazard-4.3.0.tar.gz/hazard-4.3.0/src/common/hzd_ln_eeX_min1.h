#ifndef HZD_LN_EEX_MIN1_H
#define HZD_LN_EEX_MIN1_H

double hzd_ln_eeX_min1(double lnX);
#endif /* HZD_LN_EEX_MIN1_H */
