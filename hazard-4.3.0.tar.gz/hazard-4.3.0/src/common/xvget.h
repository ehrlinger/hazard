#ifndef XVGET_H
#define XVGET_H

void xvget(void);

#endif /* XVGET_H */

