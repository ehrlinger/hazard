#ifndef NAMFIX_H
#define NAMFIX_H

void namfix(char *varname,long varidx);

#endif /* NAMFIX_H */
