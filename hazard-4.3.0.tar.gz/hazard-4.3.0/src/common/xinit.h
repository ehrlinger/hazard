#ifndef XINIT_H
#define XINIT_H

void xinit(void);

#endif /* XINIT_H */
