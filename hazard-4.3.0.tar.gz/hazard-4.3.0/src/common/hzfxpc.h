#ifndef HZFXPC_H
#define HZFXPC_H

void hzfxpc(char *strg,long leng,long column);

#endif /* HZFXPC_H */
