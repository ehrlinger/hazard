#ifndef  HZD_LN_EX_MIN1_H
#define  HZD_LN_EX_MIN1_H
double hzd_ln_eX_min1(double X);
#endif  /* HZD_LN_EX_MIN1_H */
