#ifndef HZD_SET_MACHN_H
#define HZD_SET_MACHN_H

void hzd_set_Machn(void);
#endif /* HZD_SET_MACHN_H */
