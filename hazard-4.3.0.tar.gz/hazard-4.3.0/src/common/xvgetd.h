#ifndef XVGETD_H
#define XVGETD_H
void xvgetd(struct namestr *xvnsparm,void *xvarparm);
#endif /* XVGETD_H */
