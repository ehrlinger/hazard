#ifndef HZFXPF_H
#define HZFXPF_H

void hzfxpf(double value,long places,long precsn,long column);

#endif /* HZFXPF_H */
