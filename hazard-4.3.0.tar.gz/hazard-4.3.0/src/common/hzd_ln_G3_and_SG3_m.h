#ifndef HZD_LN_G3_AND_SG3_M_H
#define HZD_LN_G3_AND_SG3_M_H
void hzd_ln_G3_and_SG3_m(double T, double *lnG3, double *lnSG3);
#endif /* HZD_LN_G3_AND_SG3_M_H */
