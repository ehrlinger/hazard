#ifndef STMTINIT_H
#define STMTINIT_H


struct stmtstr *stmtinit(int howmany);

#endif /* STMTINIT_H */
