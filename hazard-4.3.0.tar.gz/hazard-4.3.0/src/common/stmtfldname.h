#ifndef STMTFLDNAME_H
#define STMTFLDNAME_H

char *stmtfldname(long fldno);

#endif /* STMTFLDNAME_H */

