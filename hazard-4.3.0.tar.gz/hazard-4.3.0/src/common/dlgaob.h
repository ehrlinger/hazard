#ifndef  DLGAOB_H
#define  DLGAOB_H
double dlgaob(double A,double B);
#endif  /* DLGAOB_H */
