#ifndef HZD_EARLY_P2T_H
#define HZD_EARLY_P2T_H
void hzd_early_p2t(double *sTheta);
#endif /* HZD_EARLY_P2T_H */
