#ifndef HZD_SET_LNLIM_H
#define HZD_SET_LNLIM_H
void hzd_set_LnLim(void);
#endif /* HZD_SET_LNLIM_H */
