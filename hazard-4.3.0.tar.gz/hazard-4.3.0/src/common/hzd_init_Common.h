#ifndef HZD_INIT_COMMON_H
#define HZD_INIT_COMMON_H
void  hzd_init_Common(void);
#endif /* HZD_INIT_COMMON_H */
