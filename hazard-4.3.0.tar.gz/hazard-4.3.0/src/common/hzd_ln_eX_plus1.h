#ifndef HZD_LN_EX_PLUS1_H
#define HZD_LN_EX_PLUS1_H

double hzd_ln_eX_plus1(double X);
#endif /* HZD_LN_EX_PLUS1_H*/
