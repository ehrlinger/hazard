#ifndef HZD_THETA_TO_PARMS_H
#define HZD_THETA_TO_PARMS_H

void hzd_theta_to_parms(int chgd_E,int chgd_L);
#endif /* HZD_THETA_TO_PARMS_H */
