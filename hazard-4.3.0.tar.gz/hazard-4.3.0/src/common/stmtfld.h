#ifndef STMTFLD_H
#define STMTFLD_H

double stmtfld(long fldno);

#endif /* STMTFLD_H */
