#ifndef HZD_ERROR_H
#define HZD_ERROR_H


void hzd_Error(char *msgtext,long errnum);
#endif /* HZD_ERROR_H */
