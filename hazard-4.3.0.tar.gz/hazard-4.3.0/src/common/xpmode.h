#ifndef XPMODE_H
#define XPMODE_H

void xpmode(long setting);

#endif /* XPMODE_H */
