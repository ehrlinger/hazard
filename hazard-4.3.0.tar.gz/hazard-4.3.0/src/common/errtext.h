#ifndef ERRTEXT_H
#define ERRTEXT_H
void errtext(void);
#endif /* ERRTEXT_H */
