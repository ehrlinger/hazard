#ifndef HZF_LOG1_H
#define HZF_LOG1_H

void hzf_log1(char *strg);
 
#endif /* HZF_LOG1_H */
