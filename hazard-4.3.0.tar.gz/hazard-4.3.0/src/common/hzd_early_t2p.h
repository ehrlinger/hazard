#ifndef HZD_EARLY_T2P_H
#define HZD_EARLY_T2P_H

void hzd_early_t2p(void);
#endif /* HZD_EARLY_T2P_H */
