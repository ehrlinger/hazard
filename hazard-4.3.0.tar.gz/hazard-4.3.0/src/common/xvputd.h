#ifndef XVPUTD_H
#define XVPUTD_H
void xvputd(struct namestr *xvnsparm,void *xvarparm);
#endif /* XVPUTD_H */
