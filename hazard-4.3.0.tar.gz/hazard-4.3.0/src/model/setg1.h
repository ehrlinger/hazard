#ifndef SETG1_H
#define SETG1_H

void SETG1(void);

#endif /* SETG1_H */
