#ifndef RESTOR_H
#define RESTOR_H

void RESTOR(double *beta,long nvar,long *index,double *theta);
#endif /* RESTOR_H */
