#ifndef SETG3_H
#define SETG3_H

void SETG3(void);

#endif /* SETG3_H */
