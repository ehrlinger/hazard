#ifndef HZR_QTOD_H
#define HZR_QTOD_H
#include "common.h"

double hzr_qtod(xtended a);
#endif /* HZR_QTOD_H */
