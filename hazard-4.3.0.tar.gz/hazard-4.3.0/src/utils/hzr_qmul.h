#ifndef HZR_QMUL_H
#define HZR_QMUL_H

#include "common.h"
xtended hzr_qmul(xtended a,xtended c);
#endif /* HZR_QMUL_H */
