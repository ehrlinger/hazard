#ifndef HZR_XMUL_H
#define HZR_XMUL_H

#include "common.h"

xtended hzr_xmul(double a,double c);
#endif /* HZR_XMUL_H */
