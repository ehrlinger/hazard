#ifndef  HZR_SET_ERROR_H
#define  HZR_SET_ERROR_H

void hzr_set_error(char *location,long errorset);
#endif /* HZR_SET_ERROR_H */
