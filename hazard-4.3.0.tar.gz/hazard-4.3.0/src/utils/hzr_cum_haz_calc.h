#ifndef HZR_CUM_HAZ_CALC_H
#define HZR_CUM_HAZ_CALC_H
logical hzr_cum_haz_calc(double *cum,double *cf,double *lcf);
logical hzr_cum_haz_calc_m(double *cum,double *cf,double lcf);
#endif /* HZR_CUM_HAZ_CALC_H */
