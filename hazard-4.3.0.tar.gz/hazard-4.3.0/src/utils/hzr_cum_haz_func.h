#ifndef HZR_CUM_HAZ_FUNC_H
#define HZR_CUM_HAZ_FUNC_H
logical hzr_cum_haz_func(double t,double *cfn,double **cps,
			 double *hfn,double **hps,logical upd_mu);
#endif /* HZR_CUM_HAZ_FUNC_H */
