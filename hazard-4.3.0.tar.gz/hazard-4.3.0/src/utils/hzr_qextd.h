#ifndef HZR_QEXTD_H
#define HZR_QEXTD_H
xtended hzr_qextd(double a);
#endif /* HZR_QEXTD_H */
