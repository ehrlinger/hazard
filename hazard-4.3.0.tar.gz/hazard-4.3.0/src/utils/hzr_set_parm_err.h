#ifndef  HZR_SET_PARM_ERR_H
#define  HZR_SET_PARM_ERR_H

void hzr_set_parm_err(char *location,short int parmno);
#endif /* HZR_SET_PARM_ERR_H */

