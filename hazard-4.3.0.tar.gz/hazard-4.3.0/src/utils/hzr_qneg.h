#ifndef HZR_QNEG_H
#define HZR_QNEG_H
#include "common.h"
xtended hzr_qneg(xtended a);
#endif /* HZR_QNEG_H */
