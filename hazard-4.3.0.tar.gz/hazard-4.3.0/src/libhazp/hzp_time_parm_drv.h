#ifndef HZP_TIME_PARM_DRV_H
#define HZP_TIME_PARM_DRV_H

void hzp_time_parm_drv(void);
#endif /* HZP_TIME_PARM_DRV_H */
