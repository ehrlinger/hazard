#ifndef HZPI_H
#define HZPI_H

#include "structures.h"

struct common *hzpi(void);
#endif /* HZPI_H */
