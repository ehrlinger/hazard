#ifndef HZD_CALC_NORINV_H
#define HZD_CALC_NORINV_H

double hzd_calc_norinv(double P);
#endif /* HZD_CALC_NORINV_H */
