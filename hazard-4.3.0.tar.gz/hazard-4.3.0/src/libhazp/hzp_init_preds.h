#ifndef HZP_INIT_PREDS_H
#define HZP_INIT_PREDS_H

void hzp_init_preds(void);
#endif /* HZP_INIT_PREDS_H */
