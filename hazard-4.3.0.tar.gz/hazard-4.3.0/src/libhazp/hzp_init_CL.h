#ifndef HZP_INIT_CL_H
#define HZP_INIT_CL_H

void hzp_init_CL(void);
#endif /* HZP_INIT_CL_H */
