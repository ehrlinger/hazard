#ifndef HZP_CALC_PARM_DRV_H
#define HZP_CALC_PARM_DRV_H
void hzp_calc_parm_drv(int phase);
#endif /* HZP_CALC_PARM_DRV_H */
