#ifndef HZPO_H
#define HZPO_H

void hzpo(int optmz_parm,int do_CL);
#endif /* HZPO_H */
