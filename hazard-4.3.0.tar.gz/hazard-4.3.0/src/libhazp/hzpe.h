#ifndef HZPE_H
#define HZPE_H
void hzpe(void);
#endif /* HZPE_H */
