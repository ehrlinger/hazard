#ifndef HZP_CALC_XSX_H
#define HZP_CALC_XSX_H
double hzp_calc_XsX(double *V);
#endif /* HZP_CALC_XSX_H */
