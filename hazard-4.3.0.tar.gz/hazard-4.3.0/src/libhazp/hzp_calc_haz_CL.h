#ifndef HZP_CALC_HAZ_CL_H
#define HZP_CALC_HAZ_CL_H

void hzp_calc_haz_CL(void);
#endif /* HZP_CALC_HAZ_CL_H */
