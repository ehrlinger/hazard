#ifndef HZP_PRED_TIME_0_H
#define HZP_PRED_TIME_0_H

void hzp_pred_time_0(void);
#endif /* HZP_PRED_TIME_0_H */

