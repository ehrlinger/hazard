#ifndef HZPM_H
#define HZPM_H
void hzpm(long int obsCnt);
#endif /* HZPM_H */
