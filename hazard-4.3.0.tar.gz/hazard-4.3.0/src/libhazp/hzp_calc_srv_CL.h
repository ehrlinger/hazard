#ifndef HZP_CALC_SRC_CL_H
#define HZP_CALC_SRC_CL_H

void hzp_calc_srv_CL(void);
#endif /* HZP_CALC_SRC_CL_H */
