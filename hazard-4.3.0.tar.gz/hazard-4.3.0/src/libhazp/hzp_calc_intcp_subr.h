#ifndef HZP_CALC_INTCP_SUBR_H
#define HZP_CALC_INTCP_SUBR_H

void hzp_calc_intcp_subr(double c,double **r,short int **s);
#endif /* HZP_CALC_INTCP_SUBR_H */

