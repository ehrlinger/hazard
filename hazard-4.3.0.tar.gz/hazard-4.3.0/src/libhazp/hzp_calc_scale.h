#ifndef HZP_CALC_SCALE_H
#define HZP_CALC_SCALE_H
void hzp_calc_scale(void);
#endif /* HZP_CALC_SCALE_H */
