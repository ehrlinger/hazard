#ifndef CNDEST_H
#define CNDEST_H
void CNDEST(double *l,double *p,double *pm,double *x,
	    double *condno, long n);
#endif /* CNDEST_H */
