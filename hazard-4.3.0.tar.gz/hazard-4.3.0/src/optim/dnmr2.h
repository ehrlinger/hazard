#ifndef DNMR2_H
#define DNMR2_H

double DNMR2(double *sx,long n,long incx);

#endif /* DNMR2_H */
