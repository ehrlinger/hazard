#ifndef RQUAD_H
#define RQUAD_H

double RQUAD(double a,double b,double c);

#endif /* RQUAD_H */
