#ifndef QRUPDT_H
#define QRUPDT_H

void QRUPDT(double *m,double *u,double *v,long n);

#endif /* QRUPDT_H */
