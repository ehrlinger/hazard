#ifndef DQDOT_H
#define DQDOT_H

double DQDOT(double *x,double *y,long n);

#endif /* DQDOT_H */
