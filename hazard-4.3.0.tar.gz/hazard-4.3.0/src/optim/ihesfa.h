#ifndef IHESFA_H
#define IHESFA_H

void IHESFA(double *l,double *sx,double f0,double typf,long n);

#endif /* IHESFA_H */
