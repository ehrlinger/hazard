#ifndef JACROT_H
#define JACROT_H

void JACROT(double *m,double a,double b,long i,long n);

#endif /* JACROT_H */
