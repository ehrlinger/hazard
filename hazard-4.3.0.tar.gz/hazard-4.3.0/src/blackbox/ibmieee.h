#ifndef IBMIEEE_H
#define IBMIEEE_H
int cnxptiee(char* from, int fromtype, char* to, int totype);
#endif /* IBMIEEE_H */
