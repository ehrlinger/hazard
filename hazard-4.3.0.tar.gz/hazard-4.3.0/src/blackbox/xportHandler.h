#ifndef XPORT_HANDLER_H
#define XPORT_HANDLER_H
void   hzpxprt(char *filename, struct common *C);
#endif /* XPORT_HANDLER_H */
